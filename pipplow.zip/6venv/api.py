import requests
import re
from tkinter import *
from docx import Document

def check_url(): #Проверка ссылки на валидность
    url = "http://127.0.0.1:4444/TransferSimulator/"
    a = requests.get(url).json()['']  #Вывод текста из апи-ссылки
    name_label.config(text=a)
    pattern = r'[а-яА-ЯёЁ]+ [а-яА-ЯёЁ]+ [а-яА-ЯёЁ]+'
    check = re.fullmatch(pattern, a)
    if check != None:
        status_label.config(text="Валидные данные")
    else:
        status_label.config(text='ФИО содержит запрещенные символы')

#Отправления полученного результата из ссылки в окно
def send_result():
    doc = Document(".docx")
    table = doc.tables[0]
    row = table.add_row().cells
    #Заполняем ячейки
    row[0].text = name_label.cget("text")
    row[1].text = status_label.cget("text")
    row[2].text = "Успешно"
    doc.save(".docx")
#Окно
win = Tk()
win.title("Валидация данных")
win.geometry("600x200")
win.resizable(False, False)
btn1 = Button(win, text="Получить данные", command = check_url)#Кнопки
btn2 = Button(win, text="Отправить результаты теста", command = send_result)
name_label = Label(win, text="")
status_label = Label(win, text="")
btn1.grid(row=0, column=0, padx=10, pady=10)#Расположение кнопок
btn2.grid(row=1, column=0, padx=10, pady=10)
name_label.grid(row=0, column=1, padx=10, pady=10)
status_label.grid(row=1, column=1, padx=10, pady=10)
#Закрываем окно
win.mainloop()




# r'^[\w\.-]+@[\w\.-]+\.\w+$' - почта
# r'^\+7\(\d{3}\)\d{3}-\d{2}-\d{2}$' - телефон для формата +7(999)123-45-67
# r'^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$' - пароль 8 символов 1 буква 1 цифра
# r'^https?://[\w\.-]+\.\w+$' - url ссылка
# r'^\d{2}\.\d{2}\.\d{4}$' - формат даты, но не проверяет наличие даты в календаре
# r'^(\d{1,3}\.){3}\d{1,3}$' - ip адрес
# r'^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$' - mac адрес
# r'^\d{4} \d{6}$' - паспорт.